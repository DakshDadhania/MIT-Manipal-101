public MyClass {
    public MyClass(){
        System.out.println("Hello");
    }
}