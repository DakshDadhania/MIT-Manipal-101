import p1.p2.MyClass;
class Main{
    public static void main(String[] args){
        p1.p2.MyClass=new p1.p2.MyClass();
    }
}